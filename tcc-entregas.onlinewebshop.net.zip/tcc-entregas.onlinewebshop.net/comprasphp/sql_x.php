<?php
try{
		$HOST = "fdb25.awardspace.net";
		$BANCO = "3004282_pedidos";
		$USUARIO = "3004282_pedidos";
		$SENHA = "gabriel1";

		$PDO = new PDO("mysql:host=". $HOST . ";dbname=" . $BANCO . ";charset=utf8", $USUARIO , $SENHA );

} catch (PDOExcenption $ERRO){

echo "Erro de conecao " ;
}

?>