<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-7 col-xs-12">
				<div class="areaLocalizaID">
					<form action="" method="POST" >
						<center><h1>Cadastro de Login</h1>
							<div>Nome:<input size=70% type="text" name="nome" placeholder="digite seu nome aqui"/></div>
							<div>email:<input size=70% type="text" name="email" placeholder="digite um email valido"/></div>
							<div>Senha:<input type="password" name="senha" placeholder="senha" /></div>
							<input type="submit" name="submit" value="cadastrar" /> 
							<div class = "container">
					</form>
				</div>
			</div>
		</div>
	</div>

<?php
include('sql_x.php');
if($_SERVER['REQUEST_METHOD']== "POST"){
    
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
    
if ($nome!="" && $email!="" && $senha!="" ){
		$sql11 = "INSERT INTO `login`(`id`, `nome`, `email`, `senha`, `carrinho`) VALUES (DEFAULT,\"".$nome ."\" ,\"".$email ."\" ,".$senha ." ,\"\")";
			//echo"sql=".$sql11;
			$stmt = $PDO->prepare($sql11);
			$stmt->execute();
}
$sql11 = "SELECT * FROM `3004282_pedidos`.`login` where nome=\"" .$nome. "\" and email=\"".$email ."\" and senha=\"".$senha ."\"" ;
$stmt = $PDO->prepare($sql11);
$stmt->execute();
	while ($linha = $stmt->fetch(PDO::FETCH_OBJ)){ 
		$id=$linha->id;  
}
    
if ($nome!="" && $email!="" && $senha!="" ){
	echo "Bem vindo ".$nome ." seu numero de usuario é ".$id;
}
}//fim do post
?>

</div>
</div>