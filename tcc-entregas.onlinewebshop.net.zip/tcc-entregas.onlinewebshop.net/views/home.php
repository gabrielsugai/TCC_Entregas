<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-xs-12">
				<div id="meu_carrossel" class="carousel slide" data-ride="carousel">

					<!-- PONTOS REPRESENTATIVOS DE IMAGENS -->
					<ol class="carousel-indicators">
    					<li data-target="#meu_carrossel" data-slide-to="0" class="active"></li>
  					</ol>

					<!-- IMAGENS -->
					<div class="carousel-inner" role="listbox">
						<div class="item active">
							<img src="img/sobre.png" alt="tcc-entregas">
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-7 col-xs-12">
				<h1>Sobre</h1>
				<p>Com a chegada iminente da indústria 4.0 batendo a nossa porta, não seria sábio deixar uma das principais características dessa nova revolução industrial para ser desenvolvida de última hora. Visando que alguns dos principais pontos são as trocas de dados em tempo real, a possibilidade de efetuar suas compras de maneira rápida e fácil via internet e a entrega quase imediata, projetamos um sistema de compras para a indústria 4.0. Após o seu pedido ser realizado as informações são enviadas para um banco de dados, que serão atualizadas a cada etapa do processo, permitindo assim a possibilidade de acompanhar em tempo real em qual etapa seu pedido se encontra. As informações do pedido são enviadas para dois robôs no estoque, que se comunica entre si para realizar a separação dos itens do seu pedido e enviá-los para a entrega.
</p>
			</div>
		</div>
	</div>
</div>