<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-7 col-xs-12">
				<center><h1>Contato</h1>
				<p>Gabriel Sugai:</p>
				<p>E-mail: gabrielsugai@gmail.com</p>
				<p>Cel: (11)941358469</p></center>
			</div>
		</div>
	</div>
</div>