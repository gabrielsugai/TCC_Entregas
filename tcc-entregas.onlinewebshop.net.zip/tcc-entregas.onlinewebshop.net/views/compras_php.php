<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-xs-12">
<?php
include('sql_x.php');
$vetid= array();
$vetproduto= array();
$vetqtd1= array();
$vetqtd2= array();
$vetvalor= array();
$vetuser=array();
$id_post = $_GET['id'];

$sql21 = "SELECT SUM(valor) AS total FROM 3004282_pedidos.carrinhos where iduser=". $id_post;
//echo $sql21;
$stmt21 = $PDO->prepare($sql21);
$stmt21->execute();    
while ($linha2 = $stmt21->fetch(PDO::FETCH_OBJ)){
  $total_carrinho=$linha2->total;
}
echo"<div>";
echo "<button onclick=\"window.location.href='carrinho_php.php?id=".$id_post."';\">carrinho</button>";
//echo"<a rel=\"nofollow\" href=\"carrinho_php.php?id=". $id_post."\"target=\"_blank\">carrinho</a>";
echo"</div>";
echo"<div>";
echo "<button onclick=\"window.location.href='status_pedido.php?O_o=".$id_post."';\">acompanhar pedido</button> ";
echo"</div>";

echo"<div>";
echo "Valor a pagar: R$ ".$total_carrinho;
echo"</div>";

//echo"<p><a rel=\"nofollow\" href=\"status_pedido.php?O_o=". $id_post."\"target=\"_blank\">acompanhar pedido</a></p>";


//echo " <div><center>PRODUTOS DISPONIVEIS</center></div>" ;
//carrinho linha abaixo
//echo "<iframe width=\"80%\" height=\"200px\" frameborder=\"0\" src=\"comprasphp/carrinho_php.php\">seu browser nao suporta iframes</iframe> " ;
//echo " <iframe width=\"80%\" height=\"800px\" frameborder=\"0\" src=\"comprasphp/compras_php.php\">seu browser nao suporta iframes</iframe>";
//AKI COMECA O COMPRAS SEJA O QUE DEUS QUISER
$enviar_esp="";
$temp_id="";
$temp_id="";
$contador=0;
$sql11 = "SELECT * FROM 3004282_pedidos.compras";
$stmt = $PDO->prepare($sql11);
$stmt->execute();
echo "<table border=\"1\">";
echo "
<tr> <th>id</th> 
<th>produto</th> 
<th>quantidade</th> 
<th>valor</th>
<th>imagem</th>
<th>qtd</th>";

$print="";

while ($linha = $stmt->fetch(PDO::FETCH_OBJ)) {
    echo "<tr>";
    echo "<td>" . $linha->id . "</td>";
    echo "<td>" . $linha->produto . "</td>";
    echo "<td>" . $linha->qtd1 . "</td>";
    echo "<td>" . $linha->valor . "</td>";
    $idx=$linha->id;
    $vetid[$idx]=$linha->id;
    $vetproduto[$idx]=$linha->produto;
    $vetqtd1[$idx]=$linha->qtd1;
    $vetvalor[$idx]= $linha->valor ;  
    //echo $vetuser[1];
    echo"<td><img src=\"img/". $linha->id . ".png\" alt=\"Image1\" class=\"image_wrapper image_fr\" /> </td>";
    echo" <form action=\"\" method=\"POST\">";        
    echo "<td><input type=\"int\" size=\"5\" name=\"idp". $linha->id . "\"  placeholder=\"qtd\" ></td>";
    //echo"<td><input type=\"submit\" name=\"b".$linha->id ."\" value=\"comprar\" style=\"width: 70px; height: 40px\"></td>";
    // $bx="b".$linha->id ;
    $idp2="idp". $idx; 
    $vetqtd2[$idx]= $_POST[$idp2];
    //echo "<td>vetor".$vet[$id]."<td>";
    $contador = $contador + 1;
    $bx="";
    $idp="";
    $idp2="";
}

if (  $total_carrinho!=""){
echo " Finalize a compra para fazer uma nova compra ";
}
else{
echo"<input type=\"submit\" name=\"bx\" value=\"comprar\"  style=\"width: 70px; height: 40px\"></td>";
}
//echo"<input type=\"int\" name=\"idx3\" placeholder=\"Confirme seu ID\" >";
//tentativa botoes
//$ids= $_POST['idx3'];
$ids=$id_post;
//exemplos vetores
//$vet[0]= 10;
//$vet[1]= 20;
//if($_POST['bx']==true){
if($_SERVER['REQUEST_METHOD']== "POST" ){
  while ($contador >0){
    //echo "entrou no bota";
    //if para salvar os valores dos vetores
    if ($vetqtd2[$contador]!=""){
      if ($vetqtd2[$contador]> $vetqtd1[$contador]){
        $vetqtd2[$contador]=$vetqtd1[$contador];}
        //echo $vet[$contador];
        $vetvalor[$contador]=$vetvalor[$contador] * $vetqtd2[$contador];
        $sql34 ="INSERT INTO 3004282_pedidos.carrinhos (id, iduser, idp, item, qtd1, qtd2, valor) VALUES (DEFAULT, $ids, $vetid[$contador],\"$vetproduto[$contador]\",$vetqtd1[$contador],$vetqtd2[$contador],$vetvalor[$contador])";    
        $stmt34 = $PDO->prepare($sql34);
        $stmt34->bindParam('$ids', $ids);
        $stmt34->bindParam('$vetid[$contador]', $vetid[$contador]);
        $stmt34->bindParam('$vetproduto[$contador]', $vetproduto[$contador]);
        $stmt34->bindParam('$vetqtd1[$contador]', $vetqtd1[$contador]);
        $stmt34->bindParam('$vetqtd2[$contador]', $vetqtd1[$contador]);
        $stmt34->bindParam('$vetvalor[$contador]', $vetvalor[$contador]);
        $stmt34->execute();
        //echo $sql34; 
      }
      $contador=$contador-1;
    }
    echo "<script> location.href=\"carrinho_php.php?id=". $id_post."\";</script>";
  }
/*fim do if request method*/
?>
        </div>
      </div>
    </div>
  </div>

