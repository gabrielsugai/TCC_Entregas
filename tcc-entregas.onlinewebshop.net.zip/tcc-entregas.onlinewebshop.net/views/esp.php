<?php
include('sql_x.php');
$idu = $_GET['idu'];
$st= $_GET['sta'];

//if ($link_enviar ==""){$link_enviar =0;}

$sql11 = "SELECT * FROM 3004282_pedidos.carrinhos where status_pedido=1";
$stmt3 = $PDO->prepare($sql11);
$stmt3->execute();
while ($linha3 = $stmt3->fetch(PDO::FETCH_OBJ)){
        echo $linha3->id . ",";
        echo $linha3->iduser . ",";
        echo $linha3->idp . ",";
        echo $linha3->qtd2 . ",";
}

if ($idu!=""){
        $sql ="UPDATE 3004282_pedidos.carrinhos SET status_pedido=".$st." where iduser=". $idu;
	echo $sql;
        $stmt = $PDO->prepare($sql);
        if($stmt->execute()){ 
                echo "status alterado";	
                }
	else{
                echo "erro ao mudar o status";
                }
}
?>