<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>TCC Compras</title>

    <style type="text/css">
    /*estilos gerais*/
    .container{
        width: 50%;
        margin:0 auto;
        /*background:#BEBEBE; */ /*se precisar colocar isso aki*/
    }
/*formulario*/
        .areaLocalizaID{

            border-radius:5px;
            background: #8B814C;/*https://www.flextool.com.br/tabela_cores.html*/
            padding: 10px;

        }

        input {
            padding: 10px;
            margin: 8px 0;
            border: 2px solid #000;
            border-radius: 4px;

        }

        /*somente campo de entrada
        input[type=int] {
            width: 30%;
                    } */

        input[type=submit] {
            width:20%;
            background-color: #000080; 
            color: #fff;
            cursor: pointer;
        }

        /*estilos das tabelas*/

        table {

            border-collapse: collapse;
            width:100%;
            margin-top: 10px;

        }
        /*tituto da tabela*/
        table th {
            background-color: #000;
            color: #fff;
            height: 30px;

        }

        h1  {
            width:100%;
            
            color: #000;
            font-size: 14px;

            
        }

        h2  {
            width:100%;
            background-color: #000;
            color: #FFF;
            font-size: 20px;
            border-collapse: collapse;
            text-align: center;
        
            margin-top: 10px;

            
        }

        h4 {
            width:100%;
            background-color: #fff;
            color: #000;
            font-size: 20px;
            border-collapse: collapse;
            text-align: center;
        
            margin-top: 10px;

            
        }

    </style>


<h2>TCC COMPRAS CARRINHO

</h2>

</head>
<body>
  
<?php

$vetsub= array();
$vetidsub= array();
$i=1;

include('sql_x.php');
$id = $_GET['id'];
$enviar_esp="";

$contador=0;
$sql11 = "SELECT * FROM 3004282_pedidos.carrinhos where iduser=". $id;

//echo $sql11;
 

    $stmt = $PDO->prepare($sql11);
    $stmt->execute();



echo "<table border=\"0\">";
echo "<tr> <th>codigo</th> <th>produto</th> <th>qtd estoque</th> <th>qtd escolhido</th><th>valor unitario</th><th>imagem</th>";


 

   
  //echo" <input type=\"submit\" name=\"submit\" value=\"comprar\">";
      
  
         
         	



        
        



 $print="";

while ($linha = $stmt->fetch(PDO::FETCH_OBJ)) {


    echo "<tr>";
    
    echo "<td>" . $linha->idp . "</td>";
    echo "<td>" . $linha->item . "</td>";
    echo "<td>" . $linha->qtd1 . "</td>";
    echo "<td>" . $linha->qtd2 . "</td>";
    echo "<td>" . $linha->valor . "</td>";
   
    $vetsub[$i]= $linha->qtd3;
$vetidsub[$i]= $linha->idp;
$i=$i+1;

}


$sql21 = "SELECT SUM(valor) AS total FROM 3004282_pedidos.carrinhos where iduser=". $id;

        $stmt21 = $PDO->prepare($sql21);
        $stmt21->execute();    
        while ($linha2 = $stmt21->fetch(PDO::FETCH_OBJ)) {   $total_carrinho=$linha2->total;}
        echo"<div>";
         
 echo "   total a pagar R$=".$total_carrinho;
 echo"</div>";
 
 
 
 //botao de confirmar
 echo "<form action=\"\" method=\"POST\">";
 echo"<input type=\"submit\" name=\"bx\" value=\"Confirmar compra\" style=\"width: 120px; height: 40px\"></td>";

 if($_SERVER['REQUEST_METHOD']== "POST"){
 //echo"entrou no botao";
$sql211 = "UPDATE 3004282_pedidos.carrinhos SET status_pedido=1 where iduser=". $id;

//echo $sql211;

    $stmt = $PDO->prepare($sql211);
    $stmt->execute();
    
    
  //subistituindo as colunas compradas
  
  while($i>0){
  
  
  $sql911 = "UPDATE 3004282_pedidos.compras SET qtd1=". $vetsub[$i]." where id=".  $vetidsub[$i];

//echo $sql911;

    $stmt = $PDO->prepare($sql911);
    $stmt->execute();
    
      
    
  $i=$i-1;
  
  }
    

echo "<script> location.href=\"status_pedido.php?O_o=". $id."\";</script>";

}//if post

 //echo" </form>";
      // echo"</div>";
echo $print;

echo "</table>";

echo "<h1> </h1>";

echo "<h1> </h1>";
echo "<h1> </h1>";





?>



</div>

</body>




</html>