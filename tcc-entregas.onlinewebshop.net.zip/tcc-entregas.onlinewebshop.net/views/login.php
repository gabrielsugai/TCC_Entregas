<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-7 col-xs-12">
				<div class="areaLocalizaID">
					<form action="" method="POST" >
						<center><h1>Login</h1>
							<div>Id usuario:<input type="int" name="idx1"  placeholder="digite " /></div>
							<div>Senha:<input type="password" name="senha" placeholder="senha" /></div>
							<input type="submit" name="submit" value="logar" />

						</form>
					</div>
				</div>
			</div>
<?php
include('sql_x.php');
$vetid= array();
$vetproduto= array();
$vetqtd1= array();
$vetqtd2= array();
$vetvalor= array();
$vetuser=array();


if($_SERVER['REQUEST_METHOD']== "POST")
{
	$pass_usuario=0;
	$contador=0;

if( $_POST['idx1'] !="")
{
	$id_post = $_POST['idx1'];
}

$senha_usuario = $_POST['senha'];
$sql11 = "SELECT * FROM `3004282_pedidos`.`login` where id like  $id_post ";
$stmt = $PDO->prepare($sql11);
$stmt->execute();

while ($linha = $stmt->fetch(PDO::FETCH_OBJ))
{
	$pass_usuario=$linha->senha;
	$nome_usuario=$linha->nome;
}

if($senha_usuario !=$pass_usuario ){
	echo "<h1>usuário não autorizado </h1>";
	$sql = "SELECT * FROM `3004282_pedidos`.`login` where id like  999 ";
}

else{
echo "<h2>Bem vindo ".$nome_usuario."</h2>";
//echo "<iframe width=\"80%\" height=\"200px\" frameborder=\"0\" src=\"comprasphp/carrinho_php.php\">seu browser nao suporta iframes</iframe> " ;
//para redirecionar
echo " <iframe width=\"70%\" height=\"600px\" frameborder=\"0\" src=\"views/compras_php.php?id=".$id_post."\">seu browser nao suporta iframes</iframe>";
//echo "<meta HTTP-EQUIV='Refresh' CONTENT='0;URL=views/compras_php.php?id=".$id_post."\>";
//echo "<script type=\"text/javascript\">";
//echo "window.location = \"views/compras_php.php?id=".$id_post. "\"" ;
//echo "</script>";
}
}
/*fim do if request method*/
else{
    echo "Inicie o login para acessar as compras";
}?>
</div>
</div>
