<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-xs-12">
<?php
                
                include('sql_x.php');
                
                $sql11 = "SELECT * FROM 3004282_pedidos.compras";

    $stmt = $PDO->prepare($sql11);
    $stmt->execute();

while ($linha = $stmt->fetch(PDO::FETCH_OBJ)) {
?>
<div class=\"col-md-5 col-xs-12\">
	<?php
	echo"<td><img src=\"img/". $linha->id . ".png\"</td>";

							
						echo"<div class=\"item active\">";
					    echo "Produto $linha->id";
						echo"</div>";

                        }
                        ?>

						</div>
					</div>
				</div>
			</div>
		</div>