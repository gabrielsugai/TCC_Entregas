<footer>
	<div class="container">
		<div class="row">
			<div class="col-md-2"><a href="#"><img id="logo" src="img/logo.png"></a></div>
		<div class="row">
			<div class="col-md-12">
				<h3>Contato</h3>
				<p>Gabriel Sugai E-mail: gabrielsugai@gmail.com Cel:(11)941358469</a>.</p>
			</div>
		</div>
	</div>
	<!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</footer>
</body>
</html>