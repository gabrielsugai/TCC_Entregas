

<?php

include('sql_x.php');
$id_post = $_GET['O_o'];
    


  
              
    $sql11 = "SELECT * FROM `3004282_pedidos`.`login` where id like ".$id_post;

    $stmt = $PDO->prepare($sql11);
    $stmt->execute();
    
    

    while ($linha = $stmt->fetch(PDO::FETCH_OBJ)) {
   
   
     $nome_usuario=$linha->nome;
    }

   





    
    
    
            echo "<div>bem vindo ".$nome_usuario;
            echo"</div>";
    
    $sql11 = "SELECT * FROM 3004282_pedidos.carrinhos where iduser=".$id_post;

$stmt3 = $PDO->prepare($sql11);
$stmt3->execute();


echo "<table border=\"1\">";
echo "<tr> <th>seu ID</th> <th>Id do produto</th> <th>item</th> 
 <th>quantidade</th>	<th>valor unitario</th>	<th>estado do pedido</th> </tr>";


while ($linha3 = $stmt3->fetch(PDO::FETCH_OBJ)) {


	echo "<tr>";
	
        echo "<td>" . $linha3->iduser . "</td>";
	echo "<td>" . $linha3->idp . "</td>";
	echo "<td>" . $linha3->item . "</td>";
	
	echo "<td>" . $linha3->qtd2. "</td>";
	
        echo "<td>" . $linha3->valor . "</td>";
	
        $status= $linha3->status_pedido;
        
        if($status==""){echo "<td>nao ha pedido</td>";  }
        if($status=="0"){echo "<td>pedido no Carrinho</td>";  }
        if($status=="1"){echo "<td>Enviando Pedido para o forncecedor</td>";  }
        if($status=="2"){echo "<td>Pedido em separaçao</td>";  }
        if($status=="3"){echo "<td>Pedido enviado</td>";    }
        
        echo "</tr>	";
        
        
    
         
        }
       echo"<form action=\"\" method=\"POST\">";
if($status=="3"){ echo"<input type=\"submit\" name=\"bx\" value=\"confirmar recebimento\"  style=\"width: 150px; height: 40px\"></td>"; }  
else {echo"<p><a rel=\"nofollow\" href=\"status_pedido.php?O_o=". $id_post."\">atualizar pagina</a></p>";}
//$b = $_POST['bx'];
//echo "b1".$b;

        echo"</form>";

//if($_SERVER['REQUEST_METHOD']== "POST"  ){
if($_POST['bx']==true  ){
       
     
        echo " <P>OBRIGADO POR CONFIRMAR O RECEBIMENTO  </P> ";
                $sql ="DELETE FROM `carrinhos` WHERE iduser=".$id_post;


$stmt = $PDO->prepare($sql);


	if($stmt->execute()){ 
		echo "<P> status alterado </P>";	

	}
	else {
		echo "erro ao mudar o status";


}

}  
	
        
	
        
        
        
        
    
?>
