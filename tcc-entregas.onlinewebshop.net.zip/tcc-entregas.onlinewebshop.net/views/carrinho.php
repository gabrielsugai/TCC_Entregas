<div id="main">
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-xs-12">
				<div id="produto1" class="carousel slide" data-ride="carousel">
					<!-- IMAGENS -->
					<div class="carousel-inner" role="listbox">
						<div class="item active">
							<img src="img/1.png" alt="tcc-entregas">
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-5 col-xs-12">
				<div id="produto2" class="carousel slide" data-ride="carousel">
					<!-- IMAGENS -->
					<div class="carousel-inner" role="listbox">
						<div class="item active">
							<img src="img/2.png" alt="tcc-entregas">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>